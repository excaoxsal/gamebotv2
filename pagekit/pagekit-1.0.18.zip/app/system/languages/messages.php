<?php

// Numbers
__('1');
__('2');
__('3');
__('4');
__('5');
__('6');
__('7');
__('8');
__('9');
__('10');
__('15');
__('20');
__('25');
__('30');
__('33');
__('40');
__('50');
__('100');

// Menus
__('Settings');
__('Widgets');
__('Menus');
__('Users');
__('Permissions');
__('Roles');
__('Access');

// Permissions
__('Manage media files');
__('Manage menus');
__('Manage widgets');
__('Manage themes');
__('Manage extensions');
__('Apply system updates');
__('Access admin area');
__('Access system settings');
__('Manage user permissions');
__('Manage users');
__('Use the site in maintenance mode');
__('Warning: Give to trusted roles only; this permission has security implications.');
