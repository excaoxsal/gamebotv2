Vue.ready(_.merge(require('../../lib/permissions'), {el: '#permissions'}));
